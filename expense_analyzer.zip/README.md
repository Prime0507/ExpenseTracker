# 💰 AI-Assisted Expense Analyzer

A powerful financial analysis tool that helps users track, categorize, and visualize their spending patterns. Upload transaction data from your bank or financial institution and gain valuable insights about your financial habits.

## Features

- **CSV Data Processing**: Import transaction data in CSV format
- **Automatic Categorization**: Transactions are automatically categorized based on descriptions
- **Interactive Visualizations**: Explore your spending with charts and graphs
- **Smart Financial Insights**: Get data-driven observations about your spending patterns
- **Category Management**: Custom categorization of transactions
- **Monthly Analysis**: Track spending trends over time

## Screenshots

![Expense Analyzer App](generated-icon.png)

## How It Works

1. **Data Upload**: Users upload CSV files containing transaction data
2. **Processing**: The app automatically processes and categorizes each transaction
3. **Visualization**: Interactive charts show spending by category and over time
4. **Analysis**: Smart insights highlight key spending patterns and trends

## Technology Stack

- **Python**: Core programming language
- **Streamlit**: Web application framework
- **Pandas**: Data processing and analysis
- **Plotly**: Interactive data visualization
- **Data Analysis**: Built-in analytics for generating insights

## Getting Started

### Prerequisites

- Python 3.7+
- Required packages: streamlit, pandas, plotly

### Installation

1. Clone the repository
2. Install required packages:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the application:
   ```bash
   streamlit run app.py
   ```

## Usage Guide

1. **Upload Data**: Use the file uploader to import your CSV transaction data
   - CSV must include columns for: Date, Description, and Amount
   - Date should be in YYYY-MM-DD format
   - Amounts should be numeric (negative for expenses, positive for income)

2. **View Categorized Data**: See your transactions automatically sorted into categories

3. **Explore Visualizations**: 
   - Category Distribution (Pie Chart)
   - Monthly Spending (Bar Chart)
   - Category Breakdown (Table)

4. **Generate Insights**: Click the "Generate Spending Insights" button to receive smart observations about your spending patterns

## Project Structure

- `app.py`: Main application UI and logic
- `expense_analyzer.py`: Data processing functions
- `categorization.py`: Transaction categorization engine
- `visualization.py`: Chart and graph generation
- `ai_insights.py`: Smart financial insights generation
- `utils.py`: Utility functions
- `category_mapping.json`: Keyword to category mappings

## Sample Data

Two sample data files are included for testing:

- `sample_transactions.csv`: Basic dataset spanning 3 months
- `complex_transactions.csv`: Detailed dataset spanning 6 months

## Customization

The categorization system can be extended by modifying the `category_mapping.json` file to add new categories or keywords.

## License

This project is available for educational and personal use.

## Acknowledgments

- Streamlit for the excellent web app framework
- Plotly for the interactive visualization capabilities