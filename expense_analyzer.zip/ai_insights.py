import os
import pandas as pd
import numpy as np
from datetime import datetime

def generate_ai_insights(df):
    """
    Generate analytics-based insights about spending patterns.
    This is a fallback implementation that doesn't require an API key.
    
    Args:
        df: DataFrame with categorized transactions
    
    Returns:
        list: List of insights as strings
    """
    try:
        # Prepare transaction data for analysis
        expenses_df = df[df['Amount'] < 0].copy()
        
        # If no expense data, return a default message
        if len(expenses_df) == 0:
            return ["No expense data found for analysis."]
        
        insights = []
        
        # Get category totals and calculate percentages
        category_totals = expenses_df.groupby('Category')['Amount'].sum().abs().reset_index()
        category_totals = category_totals.sort_values('Amount', ascending=False)
        total_expenses = category_totals['Amount'].sum()
        
        # Add percentage column
        category_totals['Percentage'] = (category_totals['Amount'] / total_expenses * 100).round(1)
        
        # Generate insight about top spending category
        if len(category_totals) > 0:
            top_category = category_totals.iloc[0]
            insights.append(
                f"{top_category['Category']} is your highest spending category, accounting for "
                f"{top_category['Percentage']}% of your total expenses (${top_category['Amount']:.2f})."
            )
        
        # Generate insight about second highest category if available
        if len(category_totals) > 1:
            second_category = category_totals.iloc[1]
            insights.append(
                f"Your second highest expense is {second_category['Category']}, representing "
                f"{second_category['Percentage']}% of total spending (${second_category['Amount']:.2f})."
            )
        
        # Monthly analysis
        if 'Month' in expenses_df.columns and len(expenses_df['Month'].unique()) > 1:
            monthly_totals = expenses_df.groupby('Month')['Amount'].sum().abs().sort_index()
            
            # Find months with highest and lowest spending
            highest_month = monthly_totals.idxmax()
            lowest_month = monthly_totals.idxmin()
            
            insights.append(
                f"Your highest spending month was {highest_month} (${monthly_totals[highest_month]:.2f}), while "
                f"your lowest spending month was {lowest_month} (${monthly_totals[lowest_month]:.2f})."
            )
            
            # Check for month-over-month trends
            if len(monthly_totals) >= 2:
                last_month = monthly_totals.index[-1]
                prev_month = monthly_totals.index[-2]
                
                change_pct = ((monthly_totals[last_month] - monthly_totals[prev_month]) / 
                              monthly_totals[prev_month] * 100)
                
                if change_pct > 0:
                    insights.append(
                        f"Your spending increased by {abs(change_pct):.1f}% from {prev_month} to {last_month}."
                    )
                else:
                    insights.append(
                        f"Your spending decreased by {abs(change_pct):.1f}% from {prev_month} to {last_month}."
                    )
                    
        # Category-specific analysis
        if 'Month' in expenses_df.columns and len(expenses_df['Month'].unique()) > 1:
            # Get spending by category and month
            cat_month_totals = expenses_df.pivot_table(
                index='Category', 
                columns='Month', 
                values='Amount', 
                aggfunc='sum'
            ).fillna(0).abs()
            
            # Find categories with significant changes
            for category in cat_month_totals.index:
                if len(cat_month_totals.columns) >= 2:
                    latest_month = cat_month_totals.columns[-1]
                    prev_month = cat_month_totals.columns[-2]
                    
                    if cat_month_totals.loc[category, prev_month] > 0:
                        change_pct = ((cat_month_totals.loc[category, latest_month] - 
                                      cat_month_totals.loc[category, prev_month]) / 
                                      cat_month_totals.loc[category, prev_month] * 100)
                        
                        # Only mention significant changes (>20%)
                        if abs(change_pct) > 20:
                            direction = "increased" if change_pct > 0 else "decreased"
                            insights.append(
                                f"Your {category} spending {direction} by {abs(change_pct):.1f}% from "
                                f"{prev_month} to {latest_month}."
                            )
        
        # Add a budgeting tip if we have enough categories
        if len(category_totals) >= 3:
            # Find small categories that could be reduced
            small_cats = category_totals[category_totals['Percentage'] < 10]
            if len(small_cats) > 0:
                random_cat = small_cats.sample(1).iloc[0]
                insights.append(
                    f"Tip: Consider reviewing your {random_cat['Category']} expenses (${random_cat['Amount']:.2f}) "
                    f"for potential savings opportunities."
                )
        
        # If we don't have enough insights, add a general one
        if len(insights) < 3:
            insights.append(
                f"Your total expenses across all categories amount to ${total_expenses:.2f}."
            )
            
        # Limit to 5 insights
        return insights[:5]
    
    except Exception as e:
        print(f"Error generating insights: {str(e)}")
        return ["Unable to generate insights due to an error in the data analysis."]
