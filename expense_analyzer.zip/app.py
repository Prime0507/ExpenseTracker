import streamlit as st
import pandas as pd
import io
from expense_analyzer import process_csv, categorize_transactions
from visualization import create_category_pie_chart, create_monthly_bar_chart, create_category_breakdown_table
from ai_insights import generate_ai_insights
import utils

# Set page configuration
st.set_page_config(
    page_title="AI-Assisted Expense Analyzer",
    page_icon="💰",
    layout="wide"
)

# Initialize session state for storing data
if 'df' not in st.session_state:
    st.session_state.df = None
if 'categorized_df' not in st.session_state:
    st.session_state.categorized_df = None
if 'insights' not in st.session_state:
    st.session_state.insights = None

# Page header
st.title("💰 AI-Assisted Expense Analyzer")
st.write("Upload your financial transaction CSV to analyze and categorize your expenses.")

# File upload section
with st.container():
    st.subheader("1. Upload Transaction Data")
    
    uploaded_file = st.file_uploader("Choose a CSV file", type="csv")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("Expected CSV format:")
        example_df = pd.DataFrame({
            'Date': ['2023-01-15', '2023-01-20', '2023-01-25'],
            'Description': ['GROCERY MART PURCHASE', 'NETFLIX SUBSCRIPTION', 'SHELL GAS STATION'],
            'Amount': [45.67, 12.99, 38.50]
        })
        st.dataframe(example_df)
    
    with col2:
        st.info("""
        **Instructions:**
        1. Your CSV should include columns for Date, Description, and Amount
        2. Make sure the Date is in YYYY-MM-DD format
        3. Descriptions should be text that describes the transaction
        4. Amount should be numeric (positive for income, negative for expenses)
        """)

# Process the uploaded file
if uploaded_file is not None:
    try:
        # Process and categorize data
        df = process_csv(uploaded_file)
        categorized_df = categorize_transactions(df)
        
        # Store in session state
        st.session_state.df = df
        st.session_state.categorized_df = categorized_df
        
        # Show success message
        st.success("File processed successfully!")
        
    except Exception as e:
        st.error(f"Error processing file: {str(e)}")

# Display results if data is available
if st.session_state.categorized_df is not None:
    # Display raw data (collapsible)
    with st.expander("View Raw Transaction Data"):
        st.dataframe(st.session_state.df)
    
    # Display categorized data
    st.subheader("2. Categorized Transactions")
    st.dataframe(st.session_state.categorized_df)
    
    # Visualization section
    st.subheader("3. Expense Visualization")
    
    # Create visualization tabs
    tab1, tab2, tab3 = st.tabs(["Category Distribution", "Monthly Spending", "Category Breakdown"])
    
    with tab1:
        fig = create_category_pie_chart(st.session_state.categorized_df)
        st.plotly_chart(fig, use_container_width=True)
    
    with tab2:
        fig = create_monthly_bar_chart(st.session_state.categorized_df)
        st.plotly_chart(fig, use_container_width=True)
    
    with tab3:
        breakdown_table = create_category_breakdown_table(st.session_state.categorized_df)
        st.table(breakdown_table)
    
    # Summary section
    st.subheader("4. Expense Summary")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        total_expenses = utils.get_total_expenses(st.session_state.categorized_df)
        st.metric("Total Expenses", f"${abs(total_expenses):.2f}")
    
    with col2:
        top_category = utils.get_top_spending_category(st.session_state.categorized_df)
        st.metric("Top Spending Category", top_category["category"], 
                  f"${abs(top_category['amount']):.2f}")
    
    with col3:
        avg_transaction = utils.get_average_transaction(st.session_state.categorized_df)
        st.metric("Average Transaction", f"${abs(avg_transaction):.2f}")
    
    # Smart Insights section
    st.subheader("5. Smart Financial Insights")
    
    with st.container():
        if st.button("Generate Spending Insights"):
            with st.spinner("Analyzing your spending patterns..."):
                try:
                    insights = generate_ai_insights(st.session_state.categorized_df)
                    st.session_state.insights = insights
                except Exception as e:
                    st.error(f"Error generating insights: {str(e)}")
        
        # Display insights if available
        if st.session_state.insights:
            for insight in st.session_state.insights:
                st.info(insight)
else:
    # Show guide when no data is loaded
    st.info("Upload a CSV file to get started with your expense analysis.")
